# CalculatorHubs GitHub Translator

## Files
- `index.html`: standalone sample homepage with a Translator card and sample tool cards.
- `calculators/translator.html`: responsive translation interface.
- `api/translate.js`: Vercel serverless backend; API key stays server-side.
- `vercel.json`: Vercel configuration.

## Important before publishing
If CalculatorHubs already has a full homepage, do **not** replace its existing `index.html` with the sample. Merge only the Translator card/link into your current calculator-card grid. The included homepage is a starter sample, not a copy of your current site.

## GitHub Pages frontend
1. Add `calculators/translator.html` to your existing GitHub repository.
2. Set the `API_URL` constant in that file to your deployed backend endpoint, such as `https://your-project.vercel.app/api/translate`.
3. If you use the sample homepage, add `index.html` only after backing up your current one. If you preserve the existing homepage, add this card inside its current card grid and adapt CSS classes:
   ```html
   <a class="calculator-card" href="/calculators/translator.html">
     <div class="calculator-icon">🌐</div>
     <h3>Language Translator</h3>
     <p>Translate English, Tamil, Hindi and more languages.</p>
     <span class="calculator-link">Translate now →</span>
   </a>
   ```
4. Commit changes to your default branch and wait for GitHub Pages to publish.

## Deploy backend on Vercel
GitHub Pages cannot run the `api/translate.js` server-side function. Deploy this repository (or just the API and `vercel.json` in a separate repository) as a Vercel project.
1. In Google Cloud Console, create/select a project, enable Cloud Translation API, set up billing if required, and create an API key.
2. In Vercel project settings → Environment Variables, set:
   - `GOOGLE_TRANSLATE_API_KEY` = secret Google API key
   - `ALLOWED_ORIGINS` = `https://calculatorhubs.site,https://www.calculatorhubs.site`
3. Restrict the Google API key to Cloud Translation API and configure quotas/billing alerts.
4. Redeploy after adding environment variables.
5. Update frontend `API_URL` to the actual Vercel API URL.

## Security notes
- Never put the API key in `index.html`, `translator.html`, or any committed GitHub file.
- CORS is not authentication and does not stop direct scripts or abuse. Set provider quotas and add Vercel rate limiting / firewall or other per-IP rate limiting before public launch.
- This sample caps text at 5,000 characters and restricts supported languages but does not implement durable per-IP rate limiting.
- Verify Google Cloud Translation pricing, quotas, and data handling before launch.
