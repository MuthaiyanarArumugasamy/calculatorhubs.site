const TARGETS = new Set(["en","ta","hi","te","ml","kn","bn","mr","ur","pa","es","fr","de","it","pt","ja","ko","zh-CN","ar","ru"]);
function origins() {
  return (process.env.ALLOWED_ORIGINS || "https://calculatorhubs.site,https://www.calculatorhubs.site")
    .split(",").map(x => x.trim()).filter(Boolean);
}
module.exports = async function handler(req, res) {
  const allowed = origins();
  const origin = req.headers.origin;
  if (origin && allowed.includes(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
  }
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.setHeader("Cache-Control", "no-store");
  res.setHeader("X-Content-Type-Options", "nosniff");
  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST, OPTIONS");
    return res.status(405).json({error:"Method not allowed."});
  }
  if (origin && !allowed.includes(origin)) return res.status(403).json({error:"Origin not allowed."});
  const key = process.env.GOOGLE_TRANSLATE_API_KEY;
  if (!key) return res.status(500).json({error:"Translation service is not configured."});
  const body = req.body || {};
  const text = typeof body.text === "string" ? body.text.trim() : "";
  const target = typeof body.target === "string" ? body.target : "";
  const source = typeof body.source === "string" ? body.source : "";
  if (!text) return res.status(400).json({error:"Enter text to translate."});
  if (text.length > 5000) return res.status(413).json({error:"Text limit is 5,000 characters."});
  if (!TARGETS.has(target)) return res.status(400).json({error:"Unsupported target language."});
  if (source && (!TARGETS.has(source) || source === target)) return res.status(400).json({error:"Invalid source language."});
  try {
    const payload = {q:text, target, format:"text"};
    if (source) payload.source = source;
    const response = await fetch("https://translation.googleapis.com/language/translate/v2?key=" + encodeURIComponent(key), {
      method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(payload)
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
      console.error("Translation provider status:", response.status);
      return res.status(502).json({error:"Translation provider error. Check API configuration and quota."});
    }
    const item = result && result.data && result.data.translations && result.data.translations[0];
    if (!item || typeof item.translatedText !== "string") return res.status(502).json({error:"No translation returned."});
    const decoded = item.translatedText.replace(/&#39;/g,"'").replace(/&quot;/g,'"').replace(/&amp;/g,"&").replace(/&lt;/g,"<").replace(/&gt;/g,">");
    return res.status(200).json({translatedText:decoded, detectedSource:item.detectedSourceLanguage || null});
  } catch (err) {
    console.error("Translation request failed:", err && err.message ? err.message : "unknown");
    return res.status(500).json({error:"Unexpected server error. Please try again."});
  }
};
